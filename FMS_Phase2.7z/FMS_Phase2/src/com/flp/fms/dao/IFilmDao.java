package com.flp.fms.dao;

import java.util.ArrayList;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;



public interface IFilmDao 

{
	public void saveFilm(Film film);
	
	public ArrayList<Language> getAllLanguage();
	public ArrayList<Category> getAllCategory();
	public ArrayList<Language> getLanguage(int fid);
	public ArrayList<Actor> getActor(int fid);
	public ArrayList<Actor> getAllActor();
	public ArrayList<Film> getAllFilmId();
	public ArrayList<Language> getLanguageList(int fid);
	public ArrayList<Actor> getActorList(int fid); 
	public ArrayList<Film> searchAllFilm(Film film,String categoryValue,String language,int Actor);
	public boolean deleteFilm(int filmId);
	public void updateFilm(Film film);
	public ArrayList<Film> searchFilm(Film film);

	
}
