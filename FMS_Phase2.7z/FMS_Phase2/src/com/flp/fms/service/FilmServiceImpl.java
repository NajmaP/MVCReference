package com.flp.fms.service;

import java.util.ArrayList;

import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl

{
    // Create object of filmdao 
	
	FilmDaoImplForDB filmdao = new FilmDaoImplForDB();
	
	// Save film to insert data into the database
	
	public void saveFilm(Film film)
	{
		
		filmdao.saveFilm(film);
		
	}
	
	//Service to getAll languages from the database
	
	public ArrayList<Language> getAllLanguage()
	{
		
		return filmdao.getAllLanguage();
	}
	//Service to getAll Category from the database
	public ArrayList<Category> getAllCategory()
	{
		
		return filmdao.getAllCategory();
	}
	
	//Service to getAll Languages from the database with specific film id
	public ArrayList<Language> getLanguage(int fid)
	{
		
		return filmdao.getLanguage(fid);
		 
	}
	
	
	public ArrayList<Film> getAllFilmId()
	{
		
		return filmdao.getAllFilmId();
	}
	
	public ArrayList<Film> getAllFilms() 
	{
		
		return filmdao.getAllFilms();
	}
	public ArrayList<Language> getLanguageList(int fid)
	{
		
		return filmdao.getLanguageList(fid);
	}
	
	public ArrayList<Film> searchAllFilm(Film film,String categoryValue,String language,int  Actor)
	{		
		
		return filmdao.searchAllFilm(film, categoryValue, language, Actor);
	}
	
	public boolean deleteFilm(int filmId)
	{
		
		return filmdao.deleteFilm(filmId);
	}
	public void updateFilm(Film film)
	{
		
		 filmdao.updateFilm(film);
	}
	public ArrayList<Film> searchFilm(Film film)
	{
		return filmdao.searchFilm(film);
		
	}
	
}
