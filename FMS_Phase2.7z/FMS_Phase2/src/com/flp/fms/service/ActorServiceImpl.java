package com.flp.fms.service;

import java.util.ArrayList;
import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.domain.Actor;

public class ActorServiceImpl implements IActorService
{

FilmDaoImplForDB filmdao = new FilmDaoImplForDB();
	
//Service to getAll Actor from the database with specific film id
	public ArrayList<Actor> getActor(int fid)
	{
		
		return filmdao.getActor(fid);
	}
	
	//Service to getAll Actor from the database 
	public ArrayList<Actor> getAllActor()
	{
		
		return filmdao.getAllActor();
	}
	
	public ArrayList<Actor> getActorList(int fid)
	{
		
		return filmdao.getActorList(fid);
	}
	
}
