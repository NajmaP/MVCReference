/* Pojo Class for the Film Object*/

// Packages

package com.flp.fms.domain;
import java.util.Date;
import java.util.List;

// Class Declaration 

public class Film 
{
	private int film_Id;
	private String title;
	private String description;
	private Date release_Date;
	private List<Language>languages;
	private Language originalLanguage;
	private Date rental_Duration;
	private int length;
	private double replacement_Cost;
	private int ratings;
	private String special_Features;
	private List<Actor> actors;
	private Category category;
	
	
	
	// Default Constructor
	
	public Film()
	{}


	// Parametrized Constructor
	
	public Film(int film_Id, String title, String description, Date release_Date, List<Language> languages,
			Language originalLanguage, Date rental_Duration, int length, double replacement_Cost, int ratings,
			String special_Features, List<Actor> actors, Category category) {
		super();
		this.film_Id = film_Id;
		this.title = title;
		this.description = description;
		this.release_Date = release_Date;
		this.languages = languages;
		this.originalLanguage = originalLanguage;
		this.rental_Duration = rental_Duration;
		this.length = length;
		this.replacement_Cost = replacement_Cost;
		this.ratings = ratings;
		this.special_Features = special_Features;
		this.actors = actors;
		this.category = category;
	}


	public int getFilm_Id() {
		return film_Id;
	}

	// Getters and Setters
	
	
	public void setFilm_Id(int film_Id) {
		this.film_Id = film_Id;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public Date getRelease_Date() {
		return release_Date;
	}


	public void setRelease_Date(Date release_Date) {
		this.release_Date = release_Date;
	}


	public List<Language> getLanguages() {
		return languages;
	}


	public void setLanguages(List<Language> languages) {
		this.languages = languages;
	}


	public Language getOriginalLanguage() {
		return originalLanguage;
	}


	public void setOriginalLanguage(Language originalLanguage) {
		this.originalLanguage = originalLanguage;
	}


	public Date getRental_Duration() {
		return rental_Duration;
	}


	public void setRental_Duration(Date rental_Duration) {
		this.rental_Duration = rental_Duration;
	}


	public int getLength() {
		return length;
	}


	public void setLength(int length) {
		this.length = length;
	}


	public double getReplacement_Cost() {
		return replacement_Cost;
	}


	public void setReplacement_Cost(double replacement_Cost) {
		this.replacement_Cost = replacement_Cost;
	}


	public int getRatings() {
		return ratings;
	}


	public void setRatings(int ratings) {
		this.ratings = ratings;
	}


	public String getSpecial_Features() {
		return special_Features;
	}


	public void setSpecial_Features(String special_Features) {
		this.special_Features = special_Features;
	}


	public List<Actor> getActors() {
		return actors;
	}


	public void setActors(List<Actor> actors) {
		this.actors = actors;
	}


	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Film [film_Id=" + film_Id + ", title=" + title + ", description=" + description + ", release_Date="
				+ release_Date + ", languages=" + languages + ", originalLanguage=" + originalLanguage
				+ ", rental_Duration=" + rental_Duration + ", length=" + length + ", replacement_Cost="
				+ replacement_Cost + ", ratings=" + ratings + ", special_Features=" + special_Features + ", actors="
				+ actors + ", category=" + category + "]";
	}


	
		// TODO Auto-generated method stub
		
}
