package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

//List all Films detail in table with a Modify option

public class ModifyPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    

		IFilmService filmService=new FilmServiceImpl();
	
	//Get all Film objects in an ArrayList
		ArrayList<Film> films=filmService.getAllFilms();
	
	//create  a printWriter object		
		PrintWriter out=response.getWriter();
	
	//HTML section begins......
		
		out.println("<html>");
		out.println("<head>"
				+"<link rel='stylesheet' type='text/css' href='Css/myStyle.css'>"
				+ "</head>"
				+ "<body>"
				+ "<div style='margin-left:500px;'>  </div>"
				+ "<table border=1  style=' background-color: #c5c5c5'>"
				+ "<tr>"
				+ "<th> Film Id </th>"
				+ "<th> Name </th>"
				+ "<th>	Description	</th>"
				+ "<th>	Release Year	</th>"
				+ "<th>	Original Language	</th>"
				+ "<th>	Rental Duration	</th>"
				+ "<th> Other Lanugages"
				+ "<th> Actors"
				+ "<th>	Length	</th>"
				+ "<th>	Replacement Cost	</th>"
				+ "<th>	Category	</th>"
				+ "</tr>");
		/*Retrieving details from each Film objects and showing the corresponding
		 *  columns in each row of the table.
		 */
			
		 for(Film film:films){
				out.println("<tr>");
				out.println("<td>"+film.getFilmId()+"</td>");
				out.println("<td>"+film.getTitle()+"</td>");
				out.println("<td>"+film.getDescription()+"</td>");
				out.println("<td>"+film.getReleaseYear()+"</td>");
				out.println("<td>"+film.getOriginallanguage().getLanguage_Name()+"</td>");
				out.println("<td>"+film.getRentalDuration()+"</td>");
				List<Language>langs=new ArrayList<>();
				langs=film.getLanguage();
				out.println("<td>");
				for(Language lang:langs)
					out.println(lang.getLanguage_Name());
				out.println("</td>");
				Set<Actor> actors =new HashSet<>();
				actors=film.getActors();
				out.println("<td>");
				for(Actor act:actors)
					out.println(act.getFirstName()+" "+act.getLastName());
				out.println("</td>");
				out.println("<td>"+film.getLength()+"</td>");
				out.println("<td>"+film.getReplacementCost()+"</td>");
				out.println("<td>"+film.getCategory().getCategoryId()+"</td>");
		//Link to modify servlet	
				out.println("<td><a href='ModifyServlet?filmid="+film.getFilmId()+"'>Modify</a></td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
		
	}

	}



	


