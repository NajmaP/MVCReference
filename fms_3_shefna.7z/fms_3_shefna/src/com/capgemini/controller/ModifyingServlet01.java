package com.capgemini.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

//Save Modified film details ...
public class ModifyingServlet01 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IFilmService filmService=new FilmServiceImpl();
		
		//Create Film object and save film details		
				Film film1=new Film();
				
		 //Set Film Id	
				film1.setFilmId(Integer.parseInt(request.getParameter("filmid")));
				
		 //Set Film Title	
				film1.setTitle(request.getParameter("filmtitle"));
				
		 //Set Film Description		
				film1.setDescription(request.getParameter("filmdescription"));
				
		// Set ReleaseYear			
				Date date=new Date(request.getParameter("releasedate"));
				film1.setReleaseYear(date);	

		// Set RentalDuration		
				film1.setRentalDuration(new Date(request.getParameter("rentaldate")));
				
		 //Set Film Length		
				film1.setLength(Integer.parseInt(request.getParameter("filmduration")));
				
		//Set Actors	
				String [] actrlist=request.getParameterValues("actors");
				Set<Actor> actrs=new HashSet<>();
				for(String act:actrlist)
				{
					Actor actor1=new Actor();
					actor1.setActorId(Integer.parseInt(act));
					actrs.add(actor1);
				}
				film1.setActors(actrs);
				
		//Set Replacement cost 		
				Double fees=Double.parseDouble(request.getParameter("filmreplacementcost"));
				film1.setReplacementCost(fees);
				
		//Set Ratings	
				film1.setRatings(Integer.parseInt(request.getParameter("rating")));
				
		//Set Special Features		
				film1.setSpecialFeatures(request.getParameter("filmspecialfeatures"));
				
		//Set Original Language	
				Language lang=new Language();
				lang.setLanguage_Id(Integer.parseInt(request.getParameter("language")));
				film1.setOriginallanguage(lang);
				
		//Set OtherLanguages		
				String [] langlist=request.getParameterValues("languages");
				List<Language> langags=new ArrayList<>();
				for(String lang1:langlist)
				{
					Language langs=new Language();
					langs.setLanguage_Id(Integer.parseInt(lang1));
					langags.add(langs);
				}
				film1.setLanguage(langags);
			   
		//Set Category		
				Category cat=new Category();
				cat.setCategoryId(Integer.parseInt(request.getParameter("category")));
				film1.setCategory(cat);	
				Boolean flag=filmService.modifyFilm(film1);
				
			}

		}


