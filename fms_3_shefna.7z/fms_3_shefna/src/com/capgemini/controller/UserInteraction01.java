package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;

// Display the Create Film Form.......

public class UserInteraction01 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    
		//create  a printWriter object
		PrintWriter out=response.getWriter();
		
		
		FilmServiceImpl filmService=new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();

	    Set<Actor> actor= actorService.getActors();
	    List<Category> category=filmService.getCategory();
		List<Language> languages=filmService.getLanguages();


        out.println("<html>");
        out.println("<link rel='stylesheet' type='text/css' href='Css/myStyle.css'>");
        out.println("<head>");


        out.print("<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
		    +"<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
		    +"<script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
		    +"<script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
		    +" <script>"
	    	+" $(function() {"
	    	+" $( '#datepicker1' ).datepicker({"
	    	+"dateFormat:'dd-M-yy'"
	    	+"});"
	    	+" $( '#datepicker1' ).datepicker('show');"
	    	+"$( '#datepicker1' ).datepicker('setDate',new Date());"
	    	+"});"
	    	+" $(function() {"
	    	+"$( '#datepicker2' ).datepicker({"
	    	+" dateFormat:'dd-M-yy'"
	    	+"});"
	    	+" $( '#datepicker2' ).datepicker('show');"
	    	+"$( '#datepicker2' ).datepicker('setDate',new Date());"
	    	+" });"
	    	+"</script>");

        out.println( "<script type='text/javascript' src='script/validation.js'></script>");				out.println("");
		out.println("<title>Film Management System</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<form name='fms' method='post' action='AddFilm' onsubmit='return validateForm()'>");
		//out.println("<legend><b>Enter Details...</b></legend>");
		out.println("<h2><center>Film Registration Form</center></h2>");
		//out.print("<table>");
		out.println("<table cellpadding='10px' >");
	
		// Film Title text box
		out.println("<tr>"
			+"<td>FilmTitle:</td>"
			+"<td><input type='text' name='filmtitle' size='20' onmouseout='return  istitlevalidate()'>"
			+"<div id='titlefms' class='errMsg'> </div>"
			+"</td>"
			+"</tr>");
	  
		// Film Description text box
		out.println("<tr>"
			+"<td>Film Description:</td>"
			+"<td>"
			+"<textarea rows='4' name='filmdescription' cols='25' onmouseout='return  isdescriptionvalidate()'></textarea>"
			+"<div id='descfms' class='errMsg'> </div> "
			+"</td>"
			+"</tr>");
					
	  //Display Actor List from DataBase using drop down box
		 out.print("<tr><td>Actor</td><td>:</td>"+ "<td><select multiple name='actor'>");
	    	for(Actor actor1:actor)
	    	    {
					out.print("<option value='"+actor1.getActorId()+"'>"+actor1.getActorId()+" "+actor1.getFirstName()+" "+actor1.getLastName()+"</option>");
				}
	      out.print("</select></td></tr>");
					
     //	Release Date selection using Date Picker	
		  out.println("<tr>"
		    	+"<td>Release Date:</td>"
				+"<td>"
				+"<input type='date' name='releasedate' size='20' id='datepicker1'>"
				+"</td>"
				+"</tr>");
					
	 //	Rental Duration selection using Date Picker				
		out.println("<tr>"
				+"<td>Rental Duration:</td>"
				+"<td><input type='date' name='rentalduration' size='20' id='datepicker2' onmouseout= 'return isrentaldurationvalid()'></td>"
				+"<div id='rentaldurationfms' class='errMsg'> </div> "
				+"</tr>");
					
					
	 //	FilmLength 	
		out.println("<tr>"
				+"<td>FilmLength:</td>"
				+"<td><input type='text' name='filmlength' size='20' onmouseout='return  islengthvalid()' >"
				+"<div id='lenghtfms' class='errMsg'> </div>"
				+"</td>"
				+"</tr>"
				+"<tr>");
					
	//	Replacement Cost			
		out.println("<tr>"
				+"<td>Replacement Cost:</td>"
				+"<td><input type='text' name='replacementcost' size='20' onmouseout='return  isreplacevalid()' >"
				+"<div id='replacementcostfms' class='errMsg'> </div>"
				+"</td>"
				+"</tr>"
				+"<tr>");
					
	//  Special Features
		out.println("<tr>"
				+"<td>Special Features:</td>"
				+"<td>"
				+"<textarea rows='4' name='specialfeature' cols='25'></textarea>"
				+"</td>"
				+"</tr>");

	//Category get displayed from database using drop down box
		out.println("<tr><td>Category</td><td>:</td>" + "<td><select name='category'>");
				for(Category cat1:category)
				    {
						out.print("<option value='"+cat1.getCategoryId()+"'>"+cat1.getCategoryId()+" "+cat1.getName()+"</option>");
					}
					    out.print("</select></td></tr>");					
						
                    
	//Original Language get displayed from database using drop down box
					
		out.println("<tr><td>Original Language</td><td>:</td>" + "<td><select name='orglanguage'>");
					for(Language lang1:languages)
					{
						out.print("<option value='"+lang1.getLanguage_Id()+"'>"+lang1.getLanguage_Id()+" "+lang1.getLanguage_Name()+"</option>");
					}
					    out.print("</select></td></tr>");
					
					
					
	//Other Languages get displayed using database
					
		out.println("<tr><td>Other Languages</td><td>:</td>" + "<td><select multiple name='othrlanguage'>");
					for(Language lang1:languages)
					{
						out.print("<option value='"+lang1.getLanguage_Id()+"'>"+lang1.getLanguage_Id()+" "+lang1.getLanguage_Name()+"</option>");
					}
				    	out.print("</select></td></tr>");			
					
					
	// rating get displayed on form using drop down box
		out.println("<tr>"+"<td>Film Rating:</td>"
					+"<td>"
					+"<select name='rating'>"
					+"<option value='1'>1</option>"
					+"<option value='2'>2</option>"
					+"<option value='3'>3</option>"
					+"<option value='4'>4</option>"
					+"<option value='5'>5</option>"
					+"</select>"
					+"</td>"
					+"</tr>");
					
	//submit and reset button		
		out.println("<tr>"
					+"<td></td>"
					+"<td><input type='submit' value='Save'>"
					+"<input type='reset' value='Clear'>"
				    +"</td>"
					+"</tr>");

		out.println("</script>");   
					    
		out.println("</table>");
		out.println("</form>");
    	out.println("</body>");
		out.println("</html>");
	}

}
