package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class ModifyActor_ShowTable_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IActorService actorService=new ActorServiceImpl();
		
		//Get all Actor objects in an ArrayList
			Set<Actor> actors=actorService.getActors();
		
		//create  a printWriter object		
			PrintWriter out=response.getWriter();
		
		//HTML section begins......
			
			out.println("<html>");
			out.println("<head>"
					
					+ "</head>"
					+ "<body bg color='gray'>"
					+ "<div style='margin-left:500px;'>  </div>"
					+ "<table border=1  style=' background-color: #c5c5c5'>"
					+ "<tr>"
					+ "<th>Actor Id</th>"
					+ "<th>First Name</th>"
					+ "<th>Last Name</th>"
					+"<th>Modify</th>"
					+ "</tr>");
			/*Retrieving details from each Film objects and showing the corresponding
			 *  columns in each row of the table.
			 */
				
			 for(Actor actor:actors){
					out.println("<tr>");
					out.println("<td>"+actor.getActorId()+"</td>");
					out.println("<td>"+actor.getFirstName()+"</td>");
					out.println("<td>"+actor.getLastName()+"</td>");
					
			//Link to modify servlet	
					out.println("<td><a href='Modifying_Form_Showing_Servlet?actorid="+actor.getActorId()+"'>Modify</a></td>");
					out.println("</tr>");
				}
					out.println("</table></body>");
		
					out.println("</html>");
			
		}
	}


