package com.flp.fms.service;
import java.util.Set;

import com.flp.fms.domain.Actor;

public interface IActorService {
	public Set<Actor> getActors();

	public int addActor(Actor actor);

	Boolean deleteActor(int filmid);
	//public deleteActor(int actor_Id);
    

	public Actor getActor(int actorId);

	public int updateActor(Actor actor);
		

}
