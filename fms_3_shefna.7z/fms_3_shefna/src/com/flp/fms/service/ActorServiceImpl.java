package com.flp.fms.service;
import java.util.Set;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;
public class ActorServiceImpl implements IActorService{

	private IActorDao actorDao=new ActorDaoImplForList();
	
	@Override
	public Set<Actor> getActors() {
		
		return actorDao.getActors();
	}

	@Override
	public int addActor(Actor actor) {
		
		return actorDao.addActors(actor);
	}

	@Override
	public Boolean deleteActor(int actor_Id) {
					
		return	actorDao.deleteActor(actor_Id);
		}

	@Override
	public Actor getActor(int actorId) {
		
			return actorDao.getActor(actorId);
			}

	@Override
	public int updateActor(Actor actor) {
		
		return actorDao.updateActor(actor);
	}
		
	}




