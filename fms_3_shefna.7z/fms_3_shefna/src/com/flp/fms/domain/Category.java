package com.flp.fms.domain;

public class Category {
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + CategoryId;
		result = prime * result + ((Name == null) ? 0 : Name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Category other = (Category) obj;
		if (CategoryId != other.CategoryId)
			return false;
		if (Name == null) {
			if (other.Name != null)
				return false;
		} else if (!Name.equals(other.Name))
			return false;
		return true;
	}



	// private fields
	private int CategoryId;
	private String Name;
	
	
	// no argument constructor
	public Category() {}
	
	// constructor with arguments
	public Category(int CategoryId, String Name){
	
		super();
		this.CategoryId = CategoryId;
		this.Name = Name;
		
		
	}
     
	// Getter and Setter
	public int getCategoryId() {
		return CategoryId;
	}

	public void setCategoryId(int categoryId) {
		CategoryId = categoryId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	

	@Override
	public String toString() {
		return "Category [CategoryId=" + CategoryId + ", Name=" + Name +    "]";
	}
	
	
}
