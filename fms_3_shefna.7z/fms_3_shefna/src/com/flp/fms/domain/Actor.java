package com.flp.fms.domain;

public class Actor {

	//private fields
	private int ActorId;
	private String FirstName;
	private String LastName;
	
	
	public Actor() {
	}

	public Actor(int actorId, String firstName, String lastName) {
		super();
		ActorId = actorId;
		FirstName = firstName;
		LastName = lastName;
		
	}

	public int getActorId() {
		return ActorId;
	}

	public void setActorId(int actorId) {
		ActorId = actorId;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	
	

	@Override
	public String toString() {
		return "Actor [ActorId=" + ActorId + ", FirstName=" + FirstName + ", LastName=" + LastName + 
				"]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ActorId;
		result = prime * result + ((FirstName == null) ? 0 : FirstName.hashCode());
		result = prime * result + ((LastName == null) ? 0 : LastName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Actor other = (Actor) obj;
		if (ActorId != other.ActorId)
			return false;
		if (FirstName == null) {
			if (other.FirstName != null)
				return false;
		} else if (!FirstName.equals(other.FirstName))
			return false;
		if (LastName == null) {
			if (other.LastName != null)
				return false;
		} else if (!LastName.equals(other.LastName))
			return false;
		return true;
	}
	
	

}
