package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;

import com.flp.fms.domain.Actor;


public class ActorDaoImplForList implements IActorDao{

	
	//To select All actors from actor table
	@Override
	public Set<Actor> getActors() {
	
	//Create actor set	
	Set<Actor> actors=new HashSet<>();
	
	//Create connection instance	
     Connection con=getConnection();
	
   //select each row from actor table and assign values in actor object
		String sql="select * from ACTOR";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor1=new Actor();
				actor1.setActorId(rs.getInt(1));
				actor1.setFirstName(rs.getString(2));
				actor1.setLastName(rs.getString(3));
				actors.add(actor1);
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return actors;
		
	}

	
//	DB connection creation method
public static Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/FMSDATABASE","root","Pass1234");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return connection;
	}


@Override
public int addActors(Actor actor) {
	
	int count=0;
	Connection con=getConnection();
	String sql="insert into actor(FirstName,LastName) values(?,?)";
try {
PreparedStatement pst= con.prepareStatement(sql);
pst.setString(1, actor.getFirstName());
pst.setString(2, actor.getLastName());
count=pst.executeUpdate();
	return count;
}
catch (SQLException e) {

e.printStackTrace();
}
return count;
}



public List<Actor> getActor() {
	
	Connection con=getConnection();
	List<Actor> actors=new ArrayList<>();
	String query="select * from actor";
	
	try {
		PreparedStatement pst=con.prepareStatement(query);
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			Actor actor=new Actor();
			actor.setActorId(rs.getInt(1));
		    actor.setFirstName(rs.getString(2));
		    actor.setLastName(rs.getString(3));
		    
		    actors.add(actor);
		}
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	return actors;
}

public Boolean deleteActor(int actorId) {

	int count=0;
	boolean flag=true;
	Connection con=getConnection();
	String query="select * from film_actors where actor_Id=?";
	String sql="delete from actor where ActorId=?";
	
	try {
		PreparedStatement pst1= con.prepareStatement(query);
		pst1.setInt(1, actorId);
		ResultSet rs=pst1.executeQuery();
		if(rs.next())
			count=1;
		if(count==1){
		PreparedStatement pst= con.prepareStatement(sql);
		pst.setInt(1, actorId);
		count=pst.executeUpdate();
		  flag=false;}
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return flag;

}



@Override
public Actor getActor(int actorId) {

	Connection con=getConnection();
	Actor actor=new Actor();
	String query="select * from actor where actorId=?";
	
	try {
		PreparedStatement pst=con.prepareStatement(query);
		pst.setInt(1, actorId);
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			
			actor.setActorId(rs.getInt(1));
		    actor.setFirstName(rs.getString(2));
		    actor.setLastName(rs.getString(3));
		    
		    
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return actor;
}


@Override
public int updateActor(Actor actor) {
	    
	    int count=0;
		Connection con=getConnection();
		String sql="update actor set firstName=?,lastName=?"
				+ "	 where actorId=?";

      try {
      PreparedStatement pst= con.prepareStatement(sql);
      pst.setString(1, actor.getFirstName());
      pst.setString(2, actor.getLastName());
      pst.setInt(3,actor.getActorId());
      count=pst.executeUpdate();

con.close();
} catch (SQLException e) {

e.printStackTrace();
}

return count;
	}

	
}


