package org.flp.fms.Test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.domain.Actor;

public class ActorDaoImplForList_Test {
    
	ActorDaoImplForList actorDao=new ActorDaoImplForList();

//Test_case....1	
//	@Test
//	public void test_getActors()_size {
//		assertEquals(6, actorDao.getActors().size());
//	}
	
	
//...test case....2 .Testing Get Actor retrieves the Actor from Database
	/*@Test
	public void getActor_Test(){
	Actor actor=new Actor();
		actor.setActorId(5);
	    actor.setFirstName("Amir");
        actor.setLastName("Khan");
    assertEquals(actor, actorDao.getActor(5));
   }
	*/
	

	
	

	/*Test case.....4
	@Test
	public void getActors_Test_noDuplicateActorEntry() {
		
		Actor actor=new Actor(5,"Amir","Khan");
		assertNotEquals(actor,actorDao.getActors());
		
	}*/
	
	
	//7.Test case..5....Testing if Update Actor updates the proper Actor if ActorId Exists 
	/*@Test
	public void updateActor_Test()
	{
		Actor actor=new Actor();
		
		actor.setFirstName("Dulkhar");
		actor.setLastName("salman");
		actor.setActorId(9);
		assertEquals(1, actorDao.updateActor(actor));
	}
	*/
	

//Test case....6......Testing Add Actor adds the Actor to Database
			/*@Test
			public void addActor_Test()
			{
				Actor actor=new Actor();
				actor.setFirstName("Emma");
				actor.setLastName("Watson");
				assertEquals(1, actorDao.addActors(actor));
			}
			*/
	
	

	//8.Test...7.....Testing if Delete Existing actor
	/*	@Test
		public void deleteActor_Test()
		{
		assertEquals(false,actorDao.deleteActor(1));
		}
	*/
	


	//8.Test...8.....Testing if Delete Existing actor
		/*@Test
		public void deleteActorNotAllowIfActorInAnyFilm()
		{
		assertEquals(false,actorDao.deleteActor(1));
		}*/
	
	


	/*Test case.....3
	@Test
	public void isActorObjectIsNull() {
		
		Actor actor=null;
		assertNotEquals(actor,actorDao.getActors());
		
	} */
	
	
		
			
		
}


