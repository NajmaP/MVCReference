package org.flp.fms.Test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

public class FilmDaoImplForList_Test {
	IFilmService filmService=new FilmServiceImpl();
	
	/*....9
	@Test
 	public void filmObjectIsNullWhenSearchById()

	{
		 Film film=null;
        assertNotEquals(film, filmService.getAllFilms());
	}

	*/

 	/*@Test....10
	public void isFilmNotPresent()
	{
		 List<Film> films=filmService.getAllFilms();
		 Film film1=new Film();
		 for(Film film:films)
			 film1=film;
        assertNotEquals(film1, filmService.searchFilm(film1));
	}
	*/
	
	/*.....11
	@Test
	public void isFilmNotPresentToDelete()
	{
		
		 assertFalse(filmService.deleteFilm(50));
		
	}
	*/
	/*.....12
	@Test
	public void getLanguages_Test()
	{
		assertEquals(5,filmService.getLanguages().size());
	}*/
	
	/*@Test.....13
	public void isCategoryObjectIsNull() {
		
		Category category=null;
		assertNotEquals(category, filmService.getCategory());
		
	}
	*/
	/*...........14
	@Test
	public void getCategory_Test() {
		
		Category category=new Category(20,"ABC");
		assertNotEquals(category,filmService.getCategory());
		
	}
	*/

/*	@Test....15
	public void isLanguageObjectIsNull() {
		
		Language language=null;
		assertNotEquals(language, filmService.getLanguages());
		
	} */

	/*@Test....16
	public void noDuplicateLanguageEntry() {
		
		Language language=new Language(3,"English");
		assertNotEquals(language,filmService.getLanguages());
		
	}*/


/*	@Test.....17
public void getLanguages_checking_Valid_Language_Test() {
	
	Language language=new Language(20,"ABC");
	assertNotEquals(language,filmService.getLanguages());
	
}*/

//TEST CASE FOR LIST FOR CATEGORY...18
		/*	@Test
			public void testGetCategory_Test(){
				
				List<Category> category=new ArrayList<>();
				
				category.add(new Category(1, "Romantic"));
				category.add(new Category(2, "Family-Drama"));
				category.add(new Category(3, "Horror"));
				category.add(new Category(4, "Comedy"));
				category.add(new Category(5, "Adventure"));
				category.add(new Category(6, "Science-fiction"));
				
				
				assertEquals(category, filmService.getCategory());
				
			}
			*/
//TEST CASE FOR LIST OF LANGUAGES....19
				/*	@Test
					public void GetAllLanguages_Test(){
						

						List<Language>languages=new ArrayList<>();
						
						languages.add(new Language(1, "English"));
						languages.add(new Language(2, "Hindi"));
						languages.add(new Language(3, "Marathi"));
						languages.add(new Language(4, "Telagu"));
						languages.add(new Language(5, "Tamil"));
						languages.add(new Language(6, "Malayalam"));

						
						assertEquals(languages, filmService.getLanguages());
						
					}*/
					
					

}
