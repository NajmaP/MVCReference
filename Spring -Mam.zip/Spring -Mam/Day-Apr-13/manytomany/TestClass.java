package org.capgemini.manytomany;

import org.cap.onetoone.Customer;
import org.cap.onetoone.CustomerDetails;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass {

	public static void main(String[] args) {
		
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Delegate.class);
		config.addAnnotatedClass(Event.class);
		config.configure();
		
		new SchemaExport(config).create(true, true);
		
		SessionFactory factory= config.buildSessionFactory();
		Session session=factory.openSession();
		session.beginTransaction();
		
		Event java=new Event(101, "Java_101");
		Event oracle=new Event(102, "Oracle_102");
		
		
		
		Delegate tom=new Delegate(1, "Tom");
		Delegate sam=new Delegate(2, "sam");
		Delegate ram=new Delegate(3, "ram");
		Delegate thomson=new Delegate(4, "thomson");
		Delegate jack=new Delegate(5, "jack");
		Delegate annie=new Delegate(6, "annie");
		Delegate sinha=new Delegate(7, "sinha");
		Delegate singh=new Delegate(8, "singh");
		
		java.getDelegates().add(jack);
		java.getDelegates().add(tom);
		java.getDelegates().add(annie);
		java.getDelegates().add(singh);
		java.getDelegates().add(sinha);
		
		oracle.getDelegates().add(annie);
		oracle.getDelegates().add(tom);
		oracle.getDelegates().add(sam);
		oracle.getDelegates().add(ram);
		oracle.getDelegates().add(thomson);
		

		session.save(java);
		session.save(oracle);
		session.getTransaction().commit();
		session.close();
		
	}

}
