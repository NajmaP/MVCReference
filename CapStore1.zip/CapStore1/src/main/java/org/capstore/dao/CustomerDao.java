package org.capstore.dao;

import java.util.List;

import org.capstore.domain.Customer;
import org.capstore.domain.Login;
import org.capstore.domain.order_details;
import org.capstore.domain.product;
import org.capstore.domain.wishlist_table;

public interface CustomerDao {
	
	public void saveCustomer(Customer customer);
	public Customer searchCustomer(String email_id);
	public void deletecustomer(String email_id);
	public void updateCustomer(Customer customer);

	public boolean isvaliduser(Customer customer);
	public List<Customer> getAllCustomer();
	
	//get all orders
	
	public List<order_details> getAllOrders() ;
	public List<wishlist_table> getAllWishList();
	//public List<product> getAllProducts();


}
