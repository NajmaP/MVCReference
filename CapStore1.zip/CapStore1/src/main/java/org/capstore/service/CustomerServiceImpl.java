package org.capstore.service;

import java.util.List;

import org.capstore.dao.CustomerDao;
import org.capstore.domain.Customer;
import org.capstore.domain.Login;
import org.capstore.domain.order_details;
import org.capstore.domain.product;
import org.capstore.domain.wishlist_table;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CustomerServiceImpl implements CustomerService {


	@Autowired
	private CustomerDao customerDao;
	
	@Transactional
	public void saveCustomer(Customer customer) {
		customerDao.saveCustomer(customer);
		
	}

	@Override
	public Customer searchCustomer(String email_id) {
		// TODO Auto-generated method stub
		return customerDao.searchCustomer(email_id);
	}
	

	public void deletecustomer(String email_id) {
		
		customerDao.deletecustomer(email_id);
	}
/*
	@Override
	public Customer updateCustomer( String password, String email_id) {
		// TODO Auto-generated method stub
		return customerDao.updateCustomer(password, email_id);
	}*/
/*
	@Override
	public void saveLogin(Login login) {
		customerDao.saveLogin(login);
		
	}
*/
	@Override
	public boolean isvaliduser(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.isvaliduser(customer);
	}
@Override
	@Transactional
	public void updateCustomer(Customer customer) {
		customerDao.updateCustomer(customer);
		
	}
@Transactional
	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return customerDao.getAllCustomer();
	}
@Transactional
	@Override
	public List<order_details> getAllOrders() {
		// TODO Auto-generated method stub
		return customerDao.getAllOrders();
	}

@Override
public List<wishlist_table> getAllWishList() {
	// TODO Auto-generated method stub
	return customerDao.getAllWishList() ;
}

/*@Override
public List<product> getAllProducts() {
	// TODO Auto-generated method stub
	return customerDao.getAllProducts();
}*/


	

}
