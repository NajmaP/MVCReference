/* Class to Implement the Methods of IActorDao */


package com.flp.fms.dao;

import java.util.HashSet;
import java.util.Set;
import com.flp.fms.domain.Actor;



public class ActorDaoImplForList implements IActorDao {
	
	// Method to add the Actors into the Actor List
	
	public Set<Actor> getActor() 
	{
		Set<Actor> actor=new HashSet<>();
		actor.add(new Actor(101,"Mohan","Lal"));
		actor.add(new Actor(102,"Sharukh","Khan"));
		actor.add(new Actor(103,"Jacky","Shrof"));
		actor.add(new Actor(104,"Abhishekh","Bachan"));
		actor.add(new Actor(105,"Aishwarya ","Bachan"));	
		actor.add(new Actor(106,"Salman ","Khan"));
		actor.add(new Actor(107,"Sai","Pallavi"));
	
		return actor;
	}
	
	
	

}
