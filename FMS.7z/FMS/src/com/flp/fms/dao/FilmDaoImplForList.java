
/* This Class Interacts with the repository to perform various CRUD Operations */

package com.flp.fms.dao;
import java.util.*;
import com.flp.fms.domain.*;

public class FilmDaoImplForList implements IFilmDao {
	
	Film film = new Film();
	Film film1 = new Film();
	
	// Film Repository that stores the Film Objects
	
	private Map<Integer, Film> film_Repository=new HashMap<>();
	
//******************************************************************************************	
	// Add Languages into the Language
	
	public List<Language> getLanguages() 
	{
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telegu"));
		languages.add(new Language(4, "Marati"));
		languages.add(new Language(5, "Kananta"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));		
		return languages;
	}

	//Method to Add the Category items into the List
	
	public List<Category> getCategory() 
	{
		List<Category> category=new ArrayList<>();
		category.add(new Category(1,"Comedy"));
		category.add(new Category(2,"Romantic"));
		category.add(new Category(3,"Horror"));
		category.add(new Category(4,"Animation"));
		category.add(new Category(5,"Thriller"));
		category.add(new Category(6,"Adventure"));
		category.add(new Category(7,"History"));
		return category;
	}

	//CURD Operation
	
//******************************************************************************************	
	// Method to add film object into the Repository	
	
		public void addFilm(Film film) 
		{
			film_Repository.put(film.getFilm_Id(), film);
			
		}

//******************************************************************************************
		// Method to getAll  film object into the Repository
		
		public Map<Integer, Film> getAllFilms()
		{
			
			return film_Repository;
		}
//******************************************************************************************
		// Method to Search the Film by Id
		
		public void searchby_Id(Collection<Film> lst)
		{
				int flag = 0;
				
				System.out.println("Please Enter Film Id you want to Search");
				Scanner sc = new Scanner(System.in);
				int f_id=sc.nextInt();
				
				
			for(Film film:lst)
			{				
				
				if(f_id==film.getFilm_Id())
				{
					System.out.println("Element  Found");
					System.out.println(film);
					
				}				
				

			}
			
	}
//******************************************************************************************					
		// Method to search the film By Name 
		
		public void searchby_Name(Collection<Film> lst)
		{
				int flag = 0;
				
				System.out.println("Please Enter Film Name you want to Search");
				Scanner sc = new Scanner(System.in);
				String fname=sc.next();
				
				
			for(Film film:lst)
			{
				
				
				if(fname.equals(film.getTitle()))
				{
					System.out.println("Element  Found");
					System.out.println(film);
					
				}				
				

			}
		}
//******************************************************************************************
		// Method to search the film by Rating parameter
		
		public void searchby_Rating(Collection<Film> filmList)
		{
				int flag = 0;
				
				System.out.println("Please Enter Film Rating that you want to Search");
				Scanner sc = new Scanner(System.in);
				int rate=sc.nextInt();
				
				
			for(Film film: filmList)
			{
				
				
				if(rate==film.getRatings())
				{
					System.out.println("Element  Found");
					System.out.println(film);
					
				}
					
				

			}
		}
			
	//******************************************************************************************
		// Method to delete the film searching by FilmId parameter
			
			public void removeby_Id(Collection<Film> filmList)
			{
					
					
					System.out.println("Please Enter Film Id you want to delete");
					Scanner sc = new Scanner(System.in);
					int f_id=sc.nextInt();
					
					
				for(Film film:filmList)
				{
					
					
					if(f_id==film.getFilm_Id())
					{
						System.out.println("Element  Found");
						filmList.remove(film);
						
					}
						
					

				}
				  
			}
	//******************************************************************************************		
			
		// Method to Delete Film searching by Rating Parameter
			
			public void removeby_Rating(Collection<Film> filmList)
			{
					int flag = 0;
					
					System.out.println("Please Enter Film Rating that you want to Remove");
					Scanner sc = new Scanner(System.in);
					int rate=sc.nextInt();
					
					
				for(Film film:filmList)
				{
					
					
					if(rate==film.getRatings())
					{
						System.out.println("Element  Found");
						filmList.remove(film);						
					}
						
					

				}
			}
		//*************************************************************************************	
			
			// Remove the data from the list search on Name parameter
			
				public void removeby_Name(Collection<Film> filmList)
				{
						
						
						System.out.println("Please Enter Film Title you want to delete");
						Scanner sc = new Scanner(System.in);
						String fname=sc.next();
						
						
					for(Film film:filmList)
					{
						
						
						if(fname.equals(film.getTitle()))
						{
							System.out.println("Element  Found");
							filmList.remove(film);
							
						}
							
						

					}
					  
				}
				
	//******************************************************************************************
		// Method to Update the Film Object in the Repository.       
    
         public void updateFilm(Film film)
         {
        	 film_Repository.put(film.getFilm_Id(), film);
         }


		
}
