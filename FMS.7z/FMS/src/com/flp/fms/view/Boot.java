/* The Execution starts from Boot class*/

// Packages

package com.flp.fms.view;
import com.flp.fms.service.*;
import java.util.*;
import com.flp.fms.domain.Film;


public class Boot
{

	public static void main(String[] args) {
	
		int choice; // For Main Menu
		int choice_search=0; // Search Menu
		int choice_delete=0; // Delete Menu
		boolean flag=false; 
		
		UserInteraction userinterface = new UserInteraction();
		IFilmService filmService=new FilmServiceImpl();
		ActorServiceImpl actorServices=new ActorServiceImpl();
		
		//*****************************************************************************************************
		
		do{
			selection();
			System.out.println("Enter your choice (Parameter on which to search):");
			Scanner sc = new Scanner(System.in);
			choice = sc.nextInt();
			
			switch(choice)
			{
			// Case 1 is to add the film object into the list
			
			case 1:
				Film film = userinterface.addFilm(filmService.getLanguages(),filmService.getCategory(),actorServices.getActor());
				filmService.addFilm(film);				
				break;
				
			// Case 2 to Update the record in the list
			//*****************************************************************************************************	
			case 2:
				Map<Integer, Film>  filmList= filmService.getAllFilms();
				Collection<Film> filmlist=filmList.values();
				
				System.out.println("Please Enter Film Id you want to Update");
				int filmid=sc.nextInt();
				
				flag = userinterface.update(filmid, filmlist);
				if(flag==true)
				{				

					Film film1 = userinterface.addFilm(filmService.getLanguages(),filmService.getCategory(),actorServices.getActor());
					filmService.update(film1, filmid);
					System.out.println(film1);
				}
				
				break;
			//*****************************************************************************************************
				
				// Case 3 to Remove the film objects in the list on various parameters.
			case 3:	
				
				Map<Integer, Film>  filmsearchList= filmService.getAllFilms();
				Collection<Film> deletelist=filmsearchList.values();


				do{
					remove_Selection();
					System.out.println("Enter your choice (Parameter on which to delete):");			
					choice_delete = sc.nextInt();
					
					switch(choice_delete)
					{
					// Delete based on filmId
					case 1:
						filmService.removeby_Id(deletelist);
						userinterface.getAllFilm(deletelist);
						break;
						
					// Delete based on Film Title
					case 2:				

						filmService.removeby_Name(deletelist);
						break;
						
					// Delete based on Film Rating	
						
					case 3:
						filmService.removeby_Rating(deletelist);
						userinterface.getAllFilm(deletelist);
						break;
						
					case 4:
						
						break;

					}

				}while(choice_delete!=4);

				break;
			//*****************************************************************************************************
				
				// Case 4 is for searching the elements in the list
				
			case 4:

				search_Selection();				
				Map<Integer, Film>  filmDeletelist= filmService.getAllFilms();
				Collection<Film> deleteList=filmDeletelist.values();

				do{
					System.out.println("Enter your choice of search:");			
					choice_search = sc.nextInt();
					switch(choice_search)
					{
					// Search based on the FilmId
					case 1:	
						filmService.searchby_Id(deleteList);
						break;
					// Search based on the Film Title
					case 2:				

						filmService.searchby_Name(deleteList);
						break;
						// Search based on the Film Rate
					case 3:
						filmService.searchby_Rating(deleteList);
						break;
						
					case 4:
						// Exit inner Menu
						break;
					}


				}while(choice_search!=4);				

				break;
		//*****************************************************************************************************
				
			case 5:
				Map<Integer, Film>  showfilmList= filmService.getAllFilms();
				Collection<Film> showlist=showfilmList.values();		    
				userinterface.getAllFilm(showlist);
				break;
			case 6:
				System.exit(0);


			}
		}while(choice!=6);
	}

	//*****************************************************************************************************
			// Static Method to display the Film Menu

			public static void selection()
			{
				
				System.out.println("------------------------------------------------------");
				System.out.println("| \t                |MENU|    \t             |");
				System.out.println("------------------------------------------------------");
				
				System.out.println("| 	   \t 1. AddFilm 	  		     |");
				System.out.println("|	   \t 2. UpdateFilm   		     |");
				System.out.println("|	   \t 3. RemoveFilm   		     |");
				System.out.println("|	   \t 4. SearchFilm   		     |");
				System.out.println("|	   \t 5. GetAllFilm   		     |");
				System.out.println("|	   \t 6. Exit   		     	 |");
				System.out.println("-----------------------------------------------------");		


			}

			//Static Method to display the SubSelection for the search option 

	//*****************************************************************************************************



	//SubSelection for the search option 

	public static void search_Selection()
	{

		System.out.println("-----------------------------------------------------------------");
		System.out.println("| \t                |SEARCH SUB MENU|    \t                     |");
		System.out.println("-----------------------------------------------------------------");
		
		System.out.println("1. Search By Film Id" );
		System.out.println("2. Search By Film Title");
		System.out.println("3. Search By Film Ratings");
		System.out.println("4. Exit");
		System.out.println("-----------------------------------------------------------------");	

	}
	
	//*****************************************************************************************************

	//SubSelection for the remove option



	public static void remove_Selection()
	{


		System.out.println("-----------------------------------------------------------------");
		System.out.println("| \t                |DELETE SUB MENU|    \t                     |");
		System.out.println("-----------------------------------------------------------------");
		System.out.println("1.Remove By Film Id" );
		System.out.println("2.Remove By Film Title");
		System.out.println("3.Remove By Film Ratings");	
		System.out.println("4.Go to Main menu");	
		System.out.println("-----------------------------------------------------------------");		


	}
	//*****************************************************************************************************



























}
