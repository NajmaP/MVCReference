		
		
		/* This Class containd methods to validate the various fields of the Film Object*/
		
		package com.flp.fms.util;
		import com.flp.fms.util.Validate;
		import com.flp.fms.domain.Language;
		import java.util.*;
		
		// This Class is basically for validating each fields with different specifications.
		
		
		public class Validate
		{
		  //************************************************************************************************
			// Validation for Title field
		
			public static boolean isValidFilmName(String title)
			{
				return title.matches("[A-Za-z0-9.,! ]+");
		
		
			}
			//************************************************************************************************
			// Validation for Release Date
			public static boolean isValidReleaseDate(String myDate)
			{
				return myDate.matches("[0123][0-9]-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-[12][890]\\d{2}");
			}
			//************************************************************************************************
		
			// Validation for Rental Date
		
			public static boolean isValidRentalDurationDate(String myDate)
			{
				return myDate.matches("[0123][0-9]-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-[12][890]\\d{2}");
			}
			//************************************************************************************************
		
			// Validation for Film Length
		
			public static boolean isValidlength(int length)
			{
				if(length>=0&&length<=1000)
				{
					return true;
		
				}
				else 
				{
					return false;
				}
			}
			//************************************************************************************************
		
			// Validation for Film Cost
		
			public static boolean isValidCost(Double cost)
			{
				if(cost>0)
				{
		
					return true;
				}
				else
				{
		
					return false;
				}
			}
			//************************************************************************************************
			// Validation for Film Rating
		
			public static boolean isValidRate(int rating)
			{
		
				if (rating>=1&&rating<=5)
				{
					return true;
		
				}
				else
				{
		
					return false;
		
				}
		
			}
			
			//************************************************************************************************
			
			// Validation for Checking Duplicate Language 
		
			public static boolean checkDuplicateLanguage(List<Language> languages,Language language){
				boolean flag=false;
		
				Iterator<Language> it= languages.iterator();
				if(languages.isEmpty())
				{
					flag=false;
				}else{
					while(it.hasNext()){
						Language language2=it.next();
						if(language.equals(language2))
						{
							flag=true;
							break;
						}
					}
				}
				return flag;
			}
			//************************************************************************************************
		
		}
