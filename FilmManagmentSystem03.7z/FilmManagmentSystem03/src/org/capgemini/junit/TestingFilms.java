package org.capgemini.junit;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;


public class TestingFilms {
	IFilmService filmService=new FilmServiceImpl();
	IActorService actorService=new ActorServiceImpl();
	IActorDao actorDao=new ActorDaoImplForList(); 
	//TEST CASES FOR  FILM
	//1.Film object should not be null
	//2.Film not present to search
	//3.Film not present to delete
	//4.Category Object is null
	//5.duplicate category entry should not be allowed
	//6.Not Valid category
	//7.Get all Category
	//8.Language Object is null
	//9.duplicate Language entry should not be allowed
	//10.Not Valid Language
    //11.get all Languages
	//12.Object is null
	//13.duplicate actor entry should not be allowed
	//14.Not Valid Actor
	//15.get All Actors

	
	@Test
	public void filmObjectIsNullWhenSearchById()
	{
		 Film film=null;
        assertNotEquals(film, filmService.getAllFilms());
	}

	
	@Test
	public void isFilmNotPresent()
	{
		 List<Film> films=filmService.getAllFilms();
		 Film film1=new Film();
		 for(Film film:films)
			 film1=film;
        assertNotEquals(film1, filmService.searchFilm(film1));
	}
	
	@Test
	public void isFilmNotPresentToDelete()
	{
		
		 assertFalse(filmService.deleteFilm(50));
		
	}
	
	@Test
	public void isListOflanguagesReturnListOfLanguages()
	{
		assertEquals(5,filmService.getLanguages().size());
	}
	@Test
	public void isCategoryObjectIsNull() {
		
		Category category=null;
		assertNotEquals(category, filmService.getCategory());
		
	}
	
	@Test
	public void isNotValidCategory() {
		
		Category category=new Category(20,"ABC");
		assertNotEquals(category,filmService.getCategory());
		
	}
	

	@Test
	public void isLanguageObjectIsNull() {
		
		Language language=null;
		assertNotEquals(language, filmService.getLanguages());
		
	} 
	@Test
	public void noDuplicateLanguageEntry() {
		
		Language language=new Language(3,"English");
		assertNotEquals(language,filmService.getLanguages());
		
	}

@Test
public void isNotValidLanguage() {
	
	Language language=new Language(20,"ABC");
	assertNotEquals(language,filmService.getLanguages());
	
}

		@Test
		public void isActorObjectIsNull() {
			
			Actor actor=null;
			assertNotEquals(actor,actorService.getActors());
			
		} 
		@Test
		public void noDuplicateActorEntry() {
			
			Actor actor=new Actor(4,"Nivin","Pauly");
			assertNotEquals(actor,actorService.getActors());
			
		}
		
		@Test
		public void isNotValidActorEntry() {
			
			Actor actor=new Actor(15,"ABC","XYZ");
			assertEquals(1, actorDao.addActors(actor));
			
		}


	
	//TEST CASE FOR LIST FOR CATEGORY
		@Test
		public void testGetCategory(){
			
			List<Category> category=new ArrayList<>();
			
			category.add(new Category(1, "Romantic"));
			category.add(new Category(2, "Family-Drama"));
			category.add(new Category(3, "Horror"));
			category.add(new Category(4, "Comedy"));
			category.add(new Category(5, "Adventure"));
			
			
			
			assertEquals(category, filmService.getCategory());
			
		}
		//TEST CASE FOR LIST OF LANGUAGES
				@Test
				public void GetAllLanguages(){
					

					List<Language>languages=new ArrayList<>();
					
					languages.add(new Language(1, "English"));
					languages.add(new Language(2, "Malayalam"));
					languages.add(new Language(3, "Hindi"));
					languages.add(new Language(4, "Marati"));
					languages.add(new Language(5, "Tamil"));
					
					assertEquals(languages, filmService.getLanguages());
					
				}


}


	