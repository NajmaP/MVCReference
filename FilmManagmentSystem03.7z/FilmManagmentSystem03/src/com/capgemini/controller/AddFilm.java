package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
//import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;
import com.mysql.fabric.Response;

/**
 * Servlet implementation class AddFilm
 */
public class AddFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
//Creating writer object
         PrintWriter out=response.getWriter();
		 IFilmService filmService=new FilmServiceImpl();
		
//To Set All Parameters 
		 
		Film film=new Film();
		film.setTitle(request.getParameter("filmtitle"));
		film.setDescription(request.getParameter("filmdescription"));
		film.setLength(Integer.parseInt(request.getParameter("filmlength")));
		Language lang=new Language(); 
		lang.setLanguage_Id(Integer.parseInt(request.getParameter("orglanguage")));
		film.setOriginallanguage(lang);
		
//To set Other Languages
		
		List<Language> languages=new ArrayList<>();
		String[] str=request.getParameterValues("othrlanguage");
		for(String str1:str){
			Language lang1=new Language(); 
			lang1.setLanguage_Id(Integer.parseInt(str1));
			languages.add(lang1);
		}
		
		film.setLanguage(languages);
		film.setRatings(Integer.parseInt(request.getParameter("rating")));
		film.setReplacementCost(Double.parseDouble(request.getParameter("replacementcost")));
		film.setReleaseYear(new Date(request.getParameter("releasedate")));
		film.setRentalDuration(new Date(request.getParameter("rentalduration")));
		film.setSpecialFeatures(request.getParameter("specialfeature"));
		
		
//To set all Actors
		 Set<Actor> actors=new HashSet();
	
		String[] str3=request.getParameterValues("actor");
		for(String str1:str3){
			Actor actor1=new Actor(); 
			actor1.setActorId(Integer.parseInt(str1));
			actors.add(actor1);
		}
		film.setActors(actors);
		
		Category cat=new Category();
		cat.setCategoryId(Integer.parseInt(request.getParameter("category")));
		film.setCategory(cat);
		
		
	
//Add Film Method to save details
		filmService.addFilm(film);
		
// Go Back to the form page
		response.sendRedirect("UserInteraction01");
	}

	
	}

