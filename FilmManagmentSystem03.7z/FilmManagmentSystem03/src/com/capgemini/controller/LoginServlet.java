package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.flp.fms.domain.LoginUser;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter out=response.getWriter();
		
		String userName=request.getParameter("uname");
		String userPwd=request.getParameter("upwd");
		
		LoginUser loginUser=new LoginUser();
		loginUser.setUserName(userName);
		loginUser.setUserPwd(userPwd);
		
		
		IFilmService filmService=new FilmServiceImpl();
		
		
		
		if(filmService.isValidLogin(loginUser)){
			//response.sendRedirect("pages/success.html");
			

			//HttpSession session=request.getSession(true);
			
			//session.setAttribute("userName", loginUser.getUserName());
				
			
			request.getRequestDispatcher("pages/MenuPage.html").forward(request, response);
			
		}else
			response.sendRedirect("pages/Loginfms.html");
		
	}

}
