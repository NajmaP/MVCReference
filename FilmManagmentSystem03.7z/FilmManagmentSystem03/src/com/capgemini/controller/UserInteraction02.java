package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class UserInteraction02
 */
public class UserInteraction02 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		FilmServiceImpl filmService=new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();

	     Set<Actor> actor= actorService.getActors();
		 List<Category> category=filmService.getCategory();
		 List<Language> languages=filmService.getLanguages();

		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head>Add Film Details</head>"
				
				+"<script type='text/javascript' src='script/validateForm.js'></script>"
				
				+"<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
				+"<script src='//code.jquery.com/jquery-1.10.2.js'></script>"
				+"<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>"
				+"<link rel='stylesheet' type='text/css' href='../Css/myStyle.css'>"
  
 
  				+"<script>"
  				+"$(function() {"
  				+"$( '#datepicker1' ).datepicker();"
  				+"});"
  				+"</script>"
  				+"<script>"
  				+"$(function() {"
  				+" $('#datepicker2').datepicker();"
  				+" });"
  				+"</script>"				
				
				
				
				+ "<body>"
				+"<form name='Film' method='post' action='AddFilm' onsubmit='return validateField()''>"
				+ "<h3>Film Management System</h3>"
 				
				+ "<table>"
				+"<tr>"
				+" <td>Title</td>"
				+"<td><input type='text' name='title' >"
				+"<div id='unameErr2' class='errMsg'></div>"
				+"</td>" 
				+"</tr>"
				
				
				+ "<tr>"				
				+ "<td>Description</td>"
				+ "<td><input type='text' name='desc'>"
				+"<div id='unameErr1' class='errMsg'></div>"
				+"</td>" 
				+"</tr>"
				
				+"<tr>"
				+"<td>Release Date</td>"
				+"<td><input type='text' name='release' id='datepicker1'></td>" 
				+"</tr>"
				+"<tr>"
				+"<td>Rental_Duration:</td>"
				+"<td><input type='text' name='rental' id='datepicker2'> </td>" 
				+"</tr>"
				+"<tr>"  
		        +"<td>Length:</td>"
			    +"<td><input type='text' name='length' onkeypress='javascript:return isNumber(event)''> </td>" 
			    +"<tr>" 
			    +"<tr>"  
				  
				  
				  +"<td>Replacement_Cost:</td>"
				  +" <td> <input type='text' name='replacecost' onkeypress='javascript:return isNumber(event)'> </td>" 
				  +"</tr>"  
				 
 				  +"<tr>" 
				  +"<td> Ratings:</td>"
				  +"<td><select name='rating'>"
				  +"<option value='1'>1</option>"
				  +"<option value='2'>2</option>"
				  +"<option value='3'>3</option>"
				  +"<option value='4'>4</option>"
				  +"<option value='5'>5</option>"
				  +"</select> </td>" 
				  +"</tr>" 
				  
				 +"<tr>"
				 +"<td> Special_Features:</td>"
				 +"<td><textarea name='special'> </textarea></td>"
				 +"</tr>"); 
				 
					 
		 out.println("<tr>");
			
		    out.println("<td>Actor</td>");
			out.println("<td>");
							
			out.println("<select multiple name='actor1'>");
			for(Actor act:actor){
			out.println( " <option value= " + act.getActorId() + ">"+act.getFirstName()+"</option>");
			}
			out.println("</select>");
			out.println("</td>");
			out.println("</tr>");
							
								
								
								out.println("<tr>");
								
							    out.println("<td>Original Language</td>");
								out.println("<td>");
												
								out.println("<select name='original'>");
								for(Language lang1:languages){
									out.print("<option value='"+lang1.getLanguage_Id()+"'>"+lang1.getLanguage_Id()+" "+lang1.getLanguage_Name()+"</option>");
								}
								out.println("</select>");
								out.println("</td>");
								out.println("</tr>");
												
						
						
				
					   out.println("<tr>");
								
					    out.println("<td>Language</td>");
						out.println("<td>");
										
						out.println("<select multiple name='mulang'>");
						for(Language lang1:languages){
							out.print("<option value='"+lang1.getLanguage_Id()+"'>"+lang1.getLanguage_Id()+" "+lang1.getLanguage_Name()+"</option>");
						}
						out.println("</select>");
						out.println("</td>");
						out.println("</tr>");
										
				
				
						 out.println("<tr>");
							
						    out.println("<td>Category</td>");
							out.println("<td>");
											
							out.println("<select name='category'>");
							for(Category catg:category){
							out.println( " <option value= " + catg.getCategoryId() + ">"+catg.getName()+"</option>");
							}
							out.println("</select>");
							out.println("</td>");
							out.println("</tr>");
											
							out.println("<tr>"+
							"<td><input class='myButton' type='submit' value='Save' >"+
							"<input class='myButton' type='reset' value='Clear'>"+	
							"</td>"+
							"</tr>"+
							"</table>"+

					         "<div id='allerr' class='errMsg'></div>");	
							
							
							
							
							 
					


						
					

				
				
				
				
				
				
				
		
			
			
				out.println("</table></form></body>");
	
				out.println("</html>");
		
		
	}
}

