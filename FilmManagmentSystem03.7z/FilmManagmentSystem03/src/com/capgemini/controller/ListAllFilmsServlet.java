		package com.capgemini.controller;

		import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;


		public class ListAllFilmsServlet extends HttpServlet {
		private static final long serialVersionUID = 1L;


		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService=new FilmServiceImpl();
		
		ArrayList<Film> films=filmService.getAllFilms();
	
		PrintWriter out=response.getWriter();
		
		//To display All Films in Database in table
		out.println("<html>");
		out.println("<head>"
				+"<link rel='stylesheet' type='text/css' href='../pages/decoration.css'>"
				+ "</head>"
				+ "<h1><center> List of All Films </center></h1>"
				+ "<body>"
				+ "<div style='margin-left:500px;'>  </div>"
				
				
				+ "<table border=1>"
				+ "<tr>"
				+ "<th> Film Id </th>"
				+ "<th> Name </th>"
				+ "<th>	Description	</th>"
				+ "<th>	Release Year	</th>"
				+ "<th>	Original Language	</th>"
				+ "<th>	Rental Duration	</th>"
				+ "<th> Other Lanugages"
				+ "<th> Actors"
				+ "<th>	Length	</th>"
				+ "<th>	Replacement Cost	</th>"
				+ "<th>	Category	</th>"
				+ "</tr>");
		
			for(Film film:films){
				out.println("<tr>");
				out.println("<td>"+film.getFilmId()+"</td>");
				out.println("<td>"+film.getTitle()+"</td>");
				out.println("<td>"+film.getDescription()+"</td>");
				out.println("<td>"+film.getReleaseYear()+"</td>");
				out.println("<td>"+film.getOriginallanguage().getLanguage_Name()+"</td>");
				out.println("<td>"+film.getRentalDuration()+"</td>");
		//Display other Languages
				List<Language>langs=new ArrayList<>();
				langs=film.getLanguage();
				out.println("<td>");
				for(Language lang:langs)
					out.println(lang.getLanguage_Name());
					out.println("</td>");
		//Display Actors	
				Set<Actor> actors =new HashSet<>();
				
				actors=film.getActors();
				out.println("<td>");
				for(Actor act:actors)
					out.println(act.getFirstName()+" "+act.getLastName());
					out.println("</td>");
				
				
				out.println("<td>"+film.getLength()+"</td>");
				out.println("<td>"+film.getReplacementCost()+"</td>");
		//Display Categories
				out.println("<td>"+film.getCategory().getName()+"</td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
					 
	}
		

}
