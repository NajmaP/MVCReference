package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.IActorService;

/**
 * Servlet implementation class AddNewActor
 */
public class AddNewActor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		IActorService actorService=new ActorServiceImpl();
		
		out.println("<html>"
				+"<head>"
				+"<title>Add Actor</title>"
				+"<link rel='stylesheet' type='text/css' href='Css/myStyle.css'>"
				+"<script type='text/javascript' src='script/validate.js'></script>"				
				+"</head>");
		
		out.println("<body>"
				+ "<h2 align='center'>Add Actor</h2>"
						+ "<form name='addActor' method='post' action='SetActorServlet'>"
						+ "<table cellpadding='10px' >"
						+ "<tr>"
						+ "<td>Actor First Name:</td>"
						+ "<td><input type='text' name='actorFirstName'></td>"
						+ "<td><span id='FirstName_Val' class='errMsg'></span><td>"
						+ "</tr>"
						+ "<tr>"
						+ "<td>Actor Last Name:</td>"
						+ "<td><input type='text' name='actorLastName'></td>"
						+ "<td><span id='LastName_Val' class='errMsg'></span><td>"
						+ "</tr>"										
						+ "<tr>"
						+ "<td colspan='2' align='center'><input type='submit' value='Add Actor' class='myBtn'><td>"
						+ "</table></form>"
						+ "</body></html>");
	}
	
	}
