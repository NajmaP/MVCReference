		package com.flp.fms.dao;

		import java.sql.Connection;
		import java.sql.DriverManager;
		import java.sql.PreparedStatement;
		import java.sql.ResultSet;
		import java.sql.SQLException;
		import java.util.HashSet;
		import java.util.Set;
		import com.flp.fms.domain.Actor;




		public class ActorDaoImplForList implements IActorDao{

	//Establish Connection with Database
			
		public static Connection getConnection(){
				
		Connection connection=null;
				
		try {
			
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("connection essablished");
				connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/FMSDATABASE","root","Pass123");
				System.out.println("Driver Registered");
					
				} catch (ClassNotFoundException e) {
				
					e.printStackTrace();
				} catch (SQLException e) {
				
					e.printStackTrace();
				}
				
				return connection;
			}
			
			@Override
			
	public Set<Actor> getActors() {
		
	Set<Actor> actors=new HashSet<>();
		
	Connection con=getConnection();
		
	String sql="select * from ACTOR";
	try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor1=new Actor();
				actor1.setActorId(rs.getInt(1));
				actor1.setFirstName(rs.getString(2));
				actor1.setLastName(rs.getString(3));
				System.out.println(actor1);
				actors.add(actor1);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return actors;
		
	}

			@Override
			public int addActors(Actor actor) {
				
				int count=0;
				Connection con=getConnection();
				String sql="insert into actor(FirstName,LastName) values(?,?)";
			try {
			PreparedStatement pst= con.prepareStatement(sql);
			pst.setString(1, actor.getFirstName());
			pst.setString(2, actor.getLastName());
			count=pst.executeUpdate();
				return count;
			}
			catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
			return count;
			}


public Boolean deleteActor(int actorId) {

		int count=0;
		boolean flag=true;
		Connection con=getConnection();
		String query="select * from film_actors where actor_Id=?";
		String sql="delete from actor where ActorId=?";
		
		try {
			PreparedStatement pst1= con.prepareStatement(query);
			pst1.setInt(1, actorId);
			ResultSet rs=pst1.executeQuery();
			if(rs.next())
				count=1;
			if(count==1){
			PreparedStatement pst= con.prepareStatement(sql);
			pst.setInt(1, actorId);
			count=pst.executeUpdate();
			  flag=false;}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
	
}

		

			
}
