function validateField(){
	var flag=true;
	var Description = Film.desc.value;
	var title = Film.title.value;
	var length = Film.length.value;
	var rental = Film.rental.value;
	var rcost = Film.replacecost.value;
	
	  if(!Film.desc.value.match(/^[a-zA-Z]+$/) && Film.desc.value !="")
		  {
	  
		  document.getElementById("unameErr1").innerHTML="*Please enter the correct description";
		  flag=false;
		  }
	  else if(!Film.title.value.match(/^[a-zA-Z]+$/) && Film.title.value !="")	  
	     {
	  
    	document.getElementById("unameErr2").innerHTML="*Please enter correct Title";
		flag=false;
		}
	  else if(Description==""||title==""||length==""||rental==""||rcost=="")
	
		{
		  document.getElementById("allerr").innerHTML="*Please enter all mandatory fields";
			flag=false;
		  
		}
	
	
	return flag;
}

