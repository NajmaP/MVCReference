package org.capgemini.inheritance;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class MainClass {

	public static void main(String[] args) {
		
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Project.class);
		config.addAnnotatedClass(Module.class);
		config.addAnnotatedClass(Task.class);
		config.configure();
		
		new SchemaExport(config).create(true, true);
		
		
		SessionFactory factory= config.buildSessionFactory();
		Session session=factory.openSession();
		session.beginTransaction();
		
		Project project=new Project("Morgan Stanley");
		
		Module module=new Module();
		module.setProjectName("Citi Bank");
		module.setModuleName("Login Module");
		
		Task task=new Task();
		task.setProjectName("Discover Account");
		task.setModuleName("Report Module");
		task.setTaskName("Daily report");
		
		session.save(project);
		session.save(module);
		session.save(task);
		
		session.getTransaction().commit();
		session.close();
		

	}

}
